﻿using System.Collections.Generic;
using System.Linq;


namespace Buchungssystem
{
    class SpeisekartenVerwaltung
    {  
        public SerializeSpeisekarte Speisekarte { get;}
             public SpeisekartenVerwaltung(){

            ArtikelEntities _context = new ArtikelEntities();
            List<TArtikel> artikel = _context.TArtikel.ToList();
            Speisekarte = new SerializeSpeisekarte();
            Speisekarte.Artikelliste = new List<SerializeSpeisekarteArtikel>();
            
           for (int i=0; i<artikel.Count; i++)
            {              
                Speisekarte.Artikelliste.Add(new SerializeSpeisekarteArtikel()
                {
                    ArtikelNr = artikel[i].ArtikelNummer,
                    Bezeichnung = artikel[i].Bezeichnung,
                    Produkthinweis = artikel[i].ProduktHinweis,
                    Einzelpreis = artikel[i].Verkaufspreis
                }) ;
            }
        }
    }
}

