﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Buchungssystem
{
    public class Controller 
    {
        public string SpeiskartePfad { get; }

        private Kunde _kunde;
        private readonly Random _generator = new Random();
        public Controller() 
        {
            SpeiskartePfad = Environment.CurrentDirectory + "\\Speisekarte.xml";
            _kunde = new Kunde
            {
                KundenNr = GeneriereZufallsNummer('K'),
                Bestellungen = new List<Bestellung>
                {
                    
                     new Bestellung()

                    {
                        Rechnung = new Rechnung
                        {
                            RechnungsDatum = DateTime.Now,
                            RechnungsNr =  GeneriereZufallsNummer('R'),

                        },
                        BestellNr = GeneriereZufallsNummer('B'),
                        BestellDatum = DateTime.Now
                    }
                }
            };
        }
        public void RefreshKunde(string name, string strasse, string plz, string ort, string rabatt)
        {
            
           _kunde.Name = name;
            _kunde.Strasse = strasse;
            _kunde.PLZ = plz;
            _kunde.Ort = ort;
            _kunde.Bestellungen[0].Rechnung.RabattProzent = UeberpruefeRabatt(rabatt);

        }

        public void RefreshSpeise(List<BestellPosition> speisenUc1BestellPositionen)
        {
            _kunde.Bestellungen[0].BestellPositionen = speisenUc1BestellPositionen;

        }

        private double UeberpruefeRabatt(string rabatt)
        {

            if (double.TryParse(rabatt, out double drabatt))
            {
                return drabatt;
            }
            else
            {
                return 0;
            }
        }

        public void Drucken(IDrucker drucken)
        {
            drucken.Kunde = _kunde;
            drucken.Dateipfad = "Rechnung " + _kunde.KundenNr;
           
            drucken.Rechnungsausgabe();
            drucken.Open(Application.StartupPath + "\\");
        }
        private string GeneriereZufallsNummer(char buchstabe)
        {
            return buchstabe + _generator.Next(0, 999999).ToString("D6");
        }

    }
}
