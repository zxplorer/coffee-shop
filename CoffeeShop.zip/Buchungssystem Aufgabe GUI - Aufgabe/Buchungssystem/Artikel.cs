﻿namespace Buchungssystem
{
    public class Artikel
    {
        public string ArtikelNr { get; set; }
        public string Bezeichnung { get; set; }
        public string Produkthinweis { get; set; }        
    }   
}