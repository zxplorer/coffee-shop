﻿using System;

namespace Buchungssystem
{
    public class Rechnung
    {
        private double summeNetto;
        private double rabattProzent;

        public string RechnungsNr { get; set; }
        public DateTime RechnungsDatum { get; set; }
        public double SummeNetto
        {

            get { return summeNetto; }
            
      
            set
            {
                summeNetto = value;
                Berechne();
            }
        }
        public double RabattProzent
        {
            get { return rabattProzent; }

            set
            {
                rabattProzent = value;
                Berechne();
            }
        }
        public double RabattPreis { get; set; }
        public double NettoMitRabatt { get; set; }
        public double UstProzent { get; set; } = 0.19;
        public double UstAufschlag { get; set; }
        public double SummeBrutto { get; set; }
        private void Berechne()
        {
            RabattPreis = Math.Round(SummeNetto * RabattProzent * -1,2);
            NettoMitRabatt = Math.Round(SummeNetto + RabattPreis,2);
            UstAufschlag = Math.Round(NettoMitRabatt * UstProzent, 2);
            SummeBrutto = Math.Round(UstAufschlag + NettoMitRabatt,2);
        
        }
    }
}