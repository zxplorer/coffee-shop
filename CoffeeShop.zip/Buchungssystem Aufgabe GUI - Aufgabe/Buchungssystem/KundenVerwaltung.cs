﻿using System.Collections.Generic;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

namespace Buchungssystem
{
    class KundenVerwaltung
    { 

        public List<Kunde> Kunden { get; set; }
    
        public KundenVerwaltung(string dateipfad)
        {
            var fabrik = new DeSerializeFabrik();
            var serializer = new XmlSerializer(typeof(SerializeKunden));
            var fileStream = new FileStream(dateipfad, FileMode.Open);
            var textReader = new XmlTextReader(fileStream);
            var serializeKunde = (SerializeKunden)serializer.Deserialize(textReader);
            textReader.Close();
            fileStream.Close();
            fileStream.Dispose();
            Kunden = fabrik.ErstelleObjektVon(serializeKunde);
        }

        public Kunde WaehleKundenMitNamen(string nachname)
        {
            return Kunden.Find(x=> x.Name.Contains(nachname));
        }
    }

}

