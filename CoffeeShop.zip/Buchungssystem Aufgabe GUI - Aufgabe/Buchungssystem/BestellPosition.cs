﻿namespace Buchungssystem
{
    public class BestellPosition
    {
        public int PositionsNr { get; set; }
        public Artikel Artikel { get; set; }
        public double EinzelPreis { get; set; }
        public int Menge { get; set; }
        public BestellPosition(int positionsNr, double einzelPreis, int menge)
        {
            PositionsNr = positionsNr;
            EinzelPreis = einzelPreis;
            Menge = menge;
        }
    }
}