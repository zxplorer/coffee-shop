﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Buchungssystem
{
    public partial class RestaurantGUI : Form
    {
        private readonly Controller _controller = new Controller();
        private Benutzeroberflaeche.SpeisenUC _speisenUc1;
        // hier bestellung uc hinzufügen ?
        private Benutzeroberflaeche.BestellungUC _bestellungUC1;
        public RestaurantGUI()
        {
            InitializeComponent();
            CreateSpeisenUc();
            CreateBestellungUC();
           
            //TODO: Kunden Oberflaeche in den Vordergrund setzen
            userControlKunde1.BringToFront();
            
            PnlAktivBtn.Location = new Point(BtnKunde.Location.X - PnlAktivBtn.Size.Width, BtnKunde.Location.Y);
        }
        private void BtnKunde_Click(object sender, EventArgs e)
        {
            //TODO: Kunden Oberflaeche in den Vordergrund setzen
            userControlKunde1.BringToFront();
            PnlAktivBtn.Location = new Point(BtnKunde.Location.X - PnlAktivBtn.Size.Width, BtnKunde.Location.Y);
            ControllerRefreshKunde();
        }
        private void BtnSpeisen_Click(object sender, EventArgs e)
        {

            
            _speisenUc1.BringToFront();
            PnlAktivBtn.Location = new Point(BtnSpeisen.Location.X - PnlAktivBtn.Size.Width, BtnSpeisen.Location.Y);
            ControllerRefreshKunde();
        }
        private void BtnBestellung_Click(object sender, EventArgs e)
        {
            _bestellungUC1.BringToFront();
            PnlAktivBtn.Location = new Point(BtnBestellung.Location.X - PnlAktivBtn.Size.Width, BtnBestellung.Location.Y);
            ControllerRefreshKunde();
        }
        private void CreateSpeisenUc()
        {
            _speisenUc1 = new Benutzeroberflaeche.SpeisenUC(_controller.SpeiskartePfad)
            {
                BackColor = Color.White,
                ForeColor = Color.FromArgb(64, 64, 64),
                Location = new Point(198, 81),
                Name = "_speisenUc1",
                Size = new Size(786, 614),
                TabIndex = 2
            };
            Controls.Add(_speisenUc1);
        }

        private void CreateBestellungUC()
        {
            _bestellungUC1 = new Benutzeroberflaeche.BestellungUC(_controller)
            {
                BackColor = Color.White,
                ForeColor = Color.FromArgb(64, 64, 64),
                Location = new Point(198, 81),
                Name = "_bestellungUC1",
                Size = new Size(786, 614),
                TabIndex = 2
            };
            Controls.Add(_bestellungUC1);
        }
        private void ControllerRefreshKunde()
        {

        // var name = kundenUC1.Controls.Find("txbName", false)[0].Text;
        var name = userControlKunde1.Controls.Find("textBox1", false)[0].Text;
            var strasse = userControlKunde1.Controls.Find("textBox2", false)[0].Text;
            var plz = userControlKunde1.Controls.Find("textBox3", false)[0].Text;
            var ort = userControlKunde1.Controls.Find("textBox4", false)[0].Text;
            var rabatt = userControlKunde1.Controls.Find("textBox6", false)[0].Text;
            _controller.RefreshKunde(name, strasse, plz, ort, rabatt);
            _controller.RefreshSpeise(_speisenUc1.BestellPositionen);
        }

      
    }
}
