﻿namespace Buchungssystem
{
    partial class RestaurantGUI
    {
       // private readonly Controller _controller = new Controller();
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RestaurantGUI));
            this.PnlOben = new System.Windows.Forms.Panel();
            this.PnlLogo = new System.Windows.Forms.Panel();
            this.PboLogo = new System.Windows.Forms.PictureBox();
            this.LblLogo = new System.Windows.Forms.Label();
            this.PnlLeft = new System.Windows.Forms.Panel();
            this.BtnBestellung = new System.Windows.Forms.Button();
            this.BtnKunde = new System.Windows.Forms.Button();
            this.BtnSpeisen = new System.Windows.Forms.Button();
            this.PnlAktivBtn = new System.Windows.Forms.Panel();
            this.userControlKunde1 = new Buchungssystem.UserControlKunde();
            this.PnlLogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PboLogo)).BeginInit();
            this.PnlLeft.SuspendLayout();
            this.SuspendLayout();
            // 
            // PnlOben
            // 
            this.PnlOben.BackColor = System.Drawing.Color.Aqua;
            this.PnlOben.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PnlOben.Dock = System.Windows.Forms.DockStyle.Top;
            this.PnlOben.Location = new System.Drawing.Point(264, 0);
            this.PnlOben.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PnlOben.Name = "PnlOben";
            this.PnlOben.Size = new System.Drawing.Size(1048, 13);
            this.PnlOben.TabIndex = 1;
            // 
            // PnlLogo
            // 
            this.PnlLogo.AutoSize = true;
            this.PnlLogo.BackColor = System.Drawing.Color.Aqua;
            this.PnlLogo.Controls.Add(this.PboLogo);
            this.PnlLogo.Controls.Add(this.LblLogo);
            this.PnlLogo.Location = new System.Drawing.Point(256, 0);
            this.PnlLogo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PnlLogo.Name = "PnlLogo";
            this.PnlLogo.Size = new System.Drawing.Size(307, 100);
            this.PnlLogo.TabIndex = 0;
            // 
            // PboLogo
            // 
            this.PboLogo.Image = global::Buchungssystem.Properties.Resources.Eis;
            this.PboLogo.Location = new System.Drawing.Point(240, 19);
            this.PboLogo.Margin = new System.Windows.Forms.Padding(4);
            this.PboLogo.Name = "PboLogo";
            this.PboLogo.Size = new System.Drawing.Size(47, 55);
            this.PboLogo.TabIndex = 3;
            this.PboLogo.TabStop = false;
            // 
            // LblLogo
            // 
            this.LblLogo.AutoSize = true;
            this.LblLogo.Font = new System.Drawing.Font("Comic Sans MS", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblLogo.ForeColor = System.Drawing.Color.Blue;
            this.LblLogo.Location = new System.Drawing.Point(14, 39);
            this.LblLogo.Name = "LblLogo";
            this.LblLogo.Size = new System.Drawing.Size(160, 35);
            this.LblLogo.TabIndex = 2;
            this.LblLogo.Text = "Coffee Shop";
            // 
            // PnlLeft
            // 
            this.PnlLeft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.PnlLeft.Controls.Add(this.PnlAktivBtn);
            this.PnlLeft.Controls.Add(this.BtnBestellung);
            this.PnlLeft.Controls.Add(this.BtnKunde);
            this.PnlLeft.Controls.Add(this.BtnSpeisen);
            this.PnlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.PnlLeft.Location = new System.Drawing.Point(0, 0);
            this.PnlLeft.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PnlLeft.Name = "PnlLeft";
            this.PnlLeft.Size = new System.Drawing.Size(264, 855);
            this.PnlLeft.TabIndex = 0;
            // 
            // BtnBestellung
            // 
            this.BtnBestellung.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BtnBestellung.FlatAppearance.BorderSize = 0;
            this.BtnBestellung.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnBestellung.Font = new System.Drawing.Font("Comic Sans MS", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnBestellung.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BtnBestellung.Image = global::Buchungssystem.Properties.Resources.Warenkorb;
            this.BtnBestellung.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnBestellung.Location = new System.Drawing.Point(24, 332);
            this.BtnBestellung.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnBestellung.Name = "BtnBestellung";
            this.BtnBestellung.Size = new System.Drawing.Size(223, 86);
            this.BtnBestellung.TabIndex = 7;
            this.BtnBestellung.Text = "Bestellung";
            this.BtnBestellung.UseVisualStyleBackColor = false;
            this.BtnBestellung.Click += new System.EventHandler(this.BtnBestellung_Click);
            // 
            // BtnKunde
            // 
            this.BtnKunde.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BtnKunde.FlatAppearance.BorderSize = 0;
            this.BtnKunde.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnKunde.Font = new System.Drawing.Font("Comic Sans MS", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnKunde.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BtnKunde.Image = global::Buchungssystem.Properties.Resources.Kunde;
            this.BtnKunde.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnKunde.Location = new System.Drawing.Point(24, 81);
            this.BtnKunde.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnKunde.Name = "BtnKunde";
            this.BtnKunde.Size = new System.Drawing.Size(225, 86);
            this.BtnKunde.TabIndex = 6;
            this.BtnKunde.Text = "Kunde";
            this.BtnKunde.UseVisualStyleBackColor = false;
            this.BtnKunde.Click += new System.EventHandler(this.BtnKunde_Click);
            // 
            // BtnSpeisen
            // 
            this.BtnSpeisen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.BtnSpeisen.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.BtnSpeisen.FlatAppearance.BorderSize = 0;
            this.BtnSpeisen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnSpeisen.Font = new System.Drawing.Font("Comic Sans MS", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSpeisen.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BtnSpeisen.Image = global::Buchungssystem.Properties.Resources.Essen;
            this.BtnSpeisen.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnSpeisen.Location = new System.Drawing.Point(24, 207);
            this.BtnSpeisen.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BtnSpeisen.Name = "BtnSpeisen";
            this.BtnSpeisen.Size = new System.Drawing.Size(225, 86);
            this.BtnSpeisen.TabIndex = 4;
            this.BtnSpeisen.Text = "Speisen";
            this.BtnSpeisen.UseVisualStyleBackColor = false;
            this.BtnSpeisen.Click += new System.EventHandler(this.BtnSpeisen_Click);
            // 
            // PnlAktivBtn
            // 
            this.PnlAktivBtn.AutoSize = true;
            this.PnlAktivBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.PnlAktivBtn.Location = new System.Drawing.Point(3, 81);
            this.PnlAktivBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PnlAktivBtn.Name = "PnlAktivBtn";
            this.PnlAktivBtn.Size = new System.Drawing.Size(15, 86);
            this.PnlAktivBtn.TabIndex = 4;
            // 
            // userControlKunde1
            // 
            this.userControlKunde1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.userControlKunde1.Location = new System.Drawing.Point(256, 98);
            this.userControlKunde1.Margin = new System.Windows.Forms.Padding(5);
            this.userControlKunde1.Name = "userControlKunde1";
            this.userControlKunde1.Size = new System.Drawing.Size(1048, 756);
            this.userControlKunde1.TabIndex = 5;
            // 
            // RestaurantGUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1312, 855);
            this.Controls.Add(this.userControlKunde1);
            this.Controls.Add(this.PnlLogo);
            this.Controls.Add(this.PnlOben);
            this.Controls.Add(this.PnlLeft);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximumSize = new System.Drawing.Size(1328, 894);
            this.MinimumSize = new System.Drawing.Size(1328, 894);
            this.Name = "RestaurantGUI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ice Cream Land - Buchungssystem";
            this.PnlLogo.ResumeLayout(false);
            this.PnlLogo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PboLogo)).EndInit();
            this.PnlLeft.ResumeLayout(false);
            this.PnlLeft.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel PnlOben;
        private System.Windows.Forms.Panel PnlLogo;
        private System.Windows.Forms.Label LblLogo;
        private System.Windows.Forms.Button BtnSpeisen;
        private System.Windows.Forms.Panel PnlLeft;
        private System.Windows.Forms.PictureBox PboLogo;
        private System.Windows.Forms.Button BtnBestellung;
        private System.Windows.Forms.Button BtnKunde;
      //  private Benutzeroberflaeche.BestellungUC bestellungUC1;
        private UserControlKunde userControlKunde1;
        private System.Windows.Forms.Panel PnlAktivBtn;
    }
}