﻿namespace Buchungssystem.Benutzeroberflaeche
{
    partial class BestellungUC
    {
        /// <summary> 
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Komponenten-Designer generierter Code

        /// <summary> 
        /// Erforderliche Methode für die Designerunterstützung. 
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1lblBestellung = new System.Windows.Forms.Label();
            this.btnXML = new System.Windows.Forms.Button();
            this.btnJSON = new System.Windows.Forms.Button();
            this.btnPDF = new System.Windows.Forms.Button();
            this.btnKonsole = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1lblBestellung
            // 
            this.label1lblBestellung.AutoSize = true;
            this.label1lblBestellung.Font = new System.Drawing.Font("Comic Sans MS", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1lblBestellung.Location = new System.Drawing.Point(31, 0);
            this.label1lblBestellung.Name = "label1lblBestellung";
            this.label1lblBestellung.Size = new System.Drawing.Size(743, 65);
            this.label1lblBestellung.TabIndex = 3;
            this.label1lblBestellung.Text = "Rechnung erstellen und drucken";
            // 
            // btnXML
            // 
            this.btnXML.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnXML.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXML.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXML.ForeColor = System.Drawing.Color.White;
            this.btnXML.Location = new System.Drawing.Point(248, 251);
            this.btnXML.Name = "btnXML";
            this.btnXML.Size = new System.Drawing.Size(202, 52);
            this.btnXML.TabIndex = 5;
            this.btnXML.Text = "Datei im XML Format";
            this.btnXML.UseVisualStyleBackColor = false;
            this.btnXML.Click += new System.EventHandler(this.btnXML_Click);
            // 
            // btnJSON
            // 
            this.btnJSON.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnJSON.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnJSON.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJSON.ForeColor = System.Drawing.Color.White;
            this.btnJSON.Location = new System.Drawing.Point(248, 342);
            this.btnJSON.Name = "btnJSON";
            this.btnJSON.Size = new System.Drawing.Size(202, 52);
            this.btnJSON.TabIndex = 6;
            this.btnJSON.Text = "Datei im JSON Format";
            this.btnJSON.UseVisualStyleBackColor = false;
            this.btnJSON.Click += new System.EventHandler(this.btnJSON_Click);
            // 
            // btnPDF
            // 
            this.btnPDF.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnPDF.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPDF.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPDF.ForeColor = System.Drawing.Color.White;
            this.btnPDF.Location = new System.Drawing.Point(248, 435);
            this.btnPDF.Name = "btnPDF";
            this.btnPDF.Size = new System.Drawing.Size(202, 52);
            this.btnPDF.TabIndex = 7;
            this.btnPDF.Text = "PDF Datei";
            this.btnPDF.UseVisualStyleBackColor = false;
            this.btnPDF.Click += new System.EventHandler(this.btnPDF_Click);
            // 
            // btnKonsole
            // 
            this.btnKonsole.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnKonsole.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnKonsole.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKonsole.ForeColor = System.Drawing.Color.White;
            this.btnKonsole.Location = new System.Drawing.Point(248, 162);
            this.btnKonsole.Name = "btnKonsole";
            this.btnKonsole.Size = new System.Drawing.Size(202, 52);
            this.btnKonsole.TabIndex = 8;
            this.btnKonsole.Text = "Konsolendrucker";
            this.btnKonsole.UseVisualStyleBackColor = false;
            this.btnKonsole.Click += new System.EventHandler(this.btnKonsole_Click);
            // 
            // BestellungUC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.btnKonsole);
            this.Controls.Add(this.btnPDF);
            this.Controls.Add(this.btnJSON);
            this.Controls.Add(this.btnXML);
            this.Controls.Add(this.label1lblBestellung);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Name = "BestellungUC";
            this.Size = new System.Drawing.Size(786, 614);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1lblBestellung;
        private System.Windows.Forms.Button btnXML;
        private System.Windows.Forms.Button btnJSON;
        private System.Windows.Forms.Button btnPDF;
        private System.Windows.Forms.Button btnKonsole;
    }
}
