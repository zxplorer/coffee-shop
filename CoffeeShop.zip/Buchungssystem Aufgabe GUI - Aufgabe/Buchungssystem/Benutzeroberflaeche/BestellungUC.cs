﻿using System.Windows.Forms;

namespace Buchungssystem.Benutzeroberflaeche
{
    public partial class BestellungUC : UserControl
    {
        Controller controllerObjekt;

        public BestellungUC(Controller var2) 
        {
            controllerObjekt = var2;
           
            InitializeComponent();
        }

        private void btnKonsole_Click(object sender, System.EventArgs e)
        {
            
            KonsolenDrucker DruckerObjekt = new KonsolenDrucker();
            controllerObjekt.Drucken(DruckerObjekt);
        }

        private void btnXML_Click(object sender, System.EventArgs e)
        {
            XMLDrucker xMLDruckerObj = new XMLDrucker();
            controllerObjekt.Drucken(xMLDruckerObj);
        }

        private void btnJSON_Click(object sender, System.EventArgs e)
        {
            JSONDrucker jSONDruckerObj = new JSONDrucker();
            controllerObjekt.Drucken(jSONDruckerObj);
        }

        private void btnPDF_Click(object sender, System.EventArgs e)
        {
            PDFDrucker pDFDruckerObj = new PDFDrucker();
            controllerObjekt.Drucken(pDFDruckerObj);
        }
    }
}
