﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Buchungssystem.Benutzeroberflaeche
{
    public partial class SpeisenUC : UserControl
    {
        public List<BestellPosition> BestellPositionen { get; set; }

        public SpeisenUC(string speiskartePfad)
        {
            InitializeComponent();
            SpeisekarteAnzeigen();
            BestellPositionen = new List<BestellPosition>();
        }

      // vorher private void SpeisekarteAnzeigen(string speiskartePfad)
        private void SpeisekarteAnzeigen()
        {
            var a = 0;
            var b = 0;
            //var verwaltung = new SpeisekartenVerwaltung(speiskartePfad);
            var verwaltung = new SpeisekartenVerwaltung();

            for (int x = 0; x < verwaltung.Speisekarte.Artikelliste.Count; x++)
            {                
                var pnlArtikel = new Panel();
                var lblPreis = new Label();
                var lblId = new Label();
                var lblBezeichnung = new Label();

                pnlArtikel.BackColor = Color.FromArgb(64, 64, 64);
                pnlArtikel.Controls.Add(lblId);
                pnlArtikel.Controls.Add(lblPreis);
                pnlArtikel.Controls.Add(lblBezeichnung);
                pnlArtikel.Location = new Point(30 + a * 150, 55 + b*90);
                pnlArtikel.Size = new Size(125, 70);
                lblBezeichnung.AutoSize = lblId.AutoSize = lblPreis.AutoSize = true;
                lblBezeichnung.Font = lblId.Font = lblPreis.Font =
                    new Font("Comic Sans MS", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
                lblBezeichnung.ForeColor = lblId.ForeColor = lblPreis.ForeColor = Color.White;

                lblBezeichnung.Location = new Point(3, 3);
                lblBezeichnung.Size = new Size(65, 23);
                lblBezeichnung.Text = verwaltung.Speisekarte.Artikelliste[x].Bezeichnung;
                lblBezeichnung.Tag = verwaltung.Speisekarte.Artikelliste[x].Produkthinweis;

                lblPreis.Location = new Point(3, 23);
                lblPreis.Size = new Size(59, 23);
                lblPreis.Text = verwaltung.Speisekarte.Artikelliste[x].Einzelpreis + " €";

                lblId.Location = new Point(3, 43);
                lblId.Size = new Size(39, 15);
                lblId.Text = verwaltung.Speisekarte.Artikelliste[x].ArtikelNr;


                pnlArtikel.Click += SpeiseHinzufuegen;

                Controls.Add(pnlArtikel);
                a++;
                if (a == 5)
                {
                    b++;
                    a = 0;
                }

            }
        }

        public void SpeiseHinzufuegen(object sender, EventArgs e)
        {
            var artikelNr = ((Panel)sender).Controls[0].Text;
            var preis = double.Parse(((Panel)sender).Controls[1].Text.Replace(" €", "").Replace(".", ","));
            var bezeichnung = ((Panel)sender).Controls[2].Text;
            var hinweis = ((Panel)sender).Controls[2].Tag + "";

            var gefundeneBestellposition = BestellPositionen.Find(x => x.Artikel.ArtikelNr == artikelNr);
            if (gefundeneBestellposition != null)
                gefundeneBestellposition.Menge++;
            else
            {
                var bp = new BestellPosition(BestellPositionen.Count + 1, preis, 1)
                {
                    Artikel = new Artikel
                    {
                        ArtikelNr = artikelNr,
                        Bezeichnung = bezeichnung,
                        Produkthinweis = hinweis
                    }
                };
                BestellPositionen.Add(bp);
            }
        }
    }
}
