﻿using System.Diagnostics;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;


namespace Buchungssystem
{
    class XMLDrucker: IDrucker
    {
        public Kunde Kunde { get; set; }
        public string Dateipfad { get; set; }
        public void Open(string pfad)
        {
            Process.Start(pfad  + Dateipfad + ".xml");
        }

        public void Rechnungsausgabe()
        {
            var fabrik = new SerializeFabrik();
            var serializer = new XmlSerializer(typeof(SerializeKunde));
            var fileStream = new FileStream(Dateipfad + ".xml", FileMode.Create);
            var textWriter = new XmlTextWriter(fileStream, Encoding.UTF8)
            {
                Indentation = 4,
                IndentChar = ' ',
                Formatting = Formatting.Indented
            };
            serializer.Serialize(textWriter, fabrik.ErstelleObjektVon(Kunde));
            textWriter.Close();
            fileStream.Close();
            fileStream.Dispose();
        }
    }
}
