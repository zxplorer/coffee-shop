﻿using System;
using System.Linq;

namespace Buchungssystem
{
    class KonsolenDrucker : IDrucker
    {
        public Kunde Kunde { get; set; }
        public string Dateipfad { get; set; }

        public void Rechnungsausgabe()
        {
            foreach (var bestellung in Kunde.Bestellungen)
            {
                var seite = 1;
                var zeile = 1;
                SeitenKopf(seite);
                RechnungsKopf(Kunde, bestellung);
                PositionsKopf();
                foreach (var bestellPosition in bestellung.BestellPositionen.OrderBy(x => x.PositionsNr))
                {
                    if (zeile % 20 == 0)
                    {
                        seite++;
                        SeitenKopf(seite);
                        PositionsKopf();
                    }
                    PositionsZeile(bestellPosition);
                    zeile++;
                }
                RechnungsFuss(bestellung.Rechnung);
            }
        }
        private void SeitenKopf(int seite)
        {
            var test = "Seite " + seite + " ";
            Console.WriteLine(test.PadLeft(Console.WindowWidth));
        }
        private void RechnungsKopf(Kunde kunde, Bestellung bestellung)
        {
            Console.WriteLine(kunde.Name.PadRight(80, ' ') + " Rechnungsdatum: " + bestellung.Rechnung.RechnungsDatum.Date.ToString("d"));
            Console.WriteLine(kunde.Strasse.PadRight(80, ' ') + " Rechnungsnummer: " + bestellung.Rechnung.RechnungsNr);
            Console.WriteLine((kunde.PLZ + " " + kunde.Ort).PadRight(80, ' ') + " Kundennummer: " + kunde.KundenNr);
            Console.WriteLine("\nIhre Bestellung " + bestellung.BestellNr + " vom " + bestellung.BestellDatum.Date.ToString("d") + "\n");
        }
        private void RechnungsFuss(Rechnung rechnung)
        {
            var rabattProzent = Convert.ToInt32(rechnung.RabattProzent * 100); var nettoSummeAusgabe = "Summe netto     " + string.Format("{0:0.00}", rechnung.SummeNetto) + " \n";
            var rabattAusgabe = "RabattProzent (" + rabattProzent + "%)     " + string.Format("{0:0.00}", rechnung.RabattPreis) + " \n";
            var nettoRabattAusgabe = "Summe netto abzgl. RabattProzent     " + string.Format("{0:0.00}", rechnung.NettoMitRabatt) + " \n";
            var ustAusgabe = "USt(" + rechnung.UstProzent * 100 + "%)     " + string.Format("{0:0.00}", rechnung.UstAufschlag) + " \n";
            var bruttoAusgabe = "Summe brutto     " + string.Format("{0:0.00}", rechnung.SummeBrutto) + " \n";

            Console.Write(nettoSummeAusgabe.PadLeft(Console.WindowWidth));
            Console.Write(rabattAusgabe.PadLeft(Console.WindowWidth));
            Console.Write(nettoRabattAusgabe.PadLeft(Console.WindowWidth));
            Console.Write(ustAusgabe.PadLeft(Console.WindowWidth));
            Console.Write(bruttoAusgabe.PadLeft(Console.WindowWidth));
        }
        private void PositionsKopf()
        {
            Console.WriteLine("Position\tArtikelNr\tBezeichnung\t\t\t\tEinzelpreis(EUR)\tMenge\tPreis(EUR)");
        }
        private void PositionsZeile(BestellPosition bestellPosition)
        {
            Console.WriteLine(bestellPosition.PositionsNr + "\t\t" + bestellPosition.Artikel.ArtikelNr + "\t\t" + bestellPosition.Artikel.Bezeichnung.PadRight(20, ' ') + "\t\t\t" + string.Format("{0:0.00}", bestellPosition.EinzelPreis) + "\t\t\t" + bestellPosition.Menge + "\t\t" + string.Format("{0:0.00}", bestellPosition.EinzelPreis * bestellPosition.Menge));
        }

        public void Open(string pfad)
        {
        
        }
    }
}
