﻿namespace Buchungssystem
{
    public interface IDrucker
    {
        void Rechnungsausgabe();
        Kunde Kunde { get; set; }
        string Dateipfad {  get; set;}

        void Open(string pfad);
    }
}
