﻿namespace Buchungssystem
{
    public class SerializeArtikel
    {
        public string ArtikelNr;
        public string Bezeichnung;
        public string Produkthinweis;
    }
}