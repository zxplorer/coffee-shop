﻿using System.Collections.Generic;

namespace Buchungssystem
{
    public class SerializeBestellung
    {
        public SerializeRechnung Rechnung;
        public string BestellNr;
        public System.DateTime BestellDatum;
        public List<SerializeBestellPosition> BestellPositionen;
    }
}