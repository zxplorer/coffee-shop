﻿using System.Collections.Generic;

namespace Buchungssystem
{
    public class SerializeKunden
    {
        public List<SerializeKunde> Kunden;
     
    }
}