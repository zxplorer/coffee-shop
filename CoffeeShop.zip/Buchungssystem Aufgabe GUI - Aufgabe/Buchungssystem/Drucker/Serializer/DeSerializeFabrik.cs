﻿using System.Collections.Generic;

namespace Buchungssystem
{
    class DeSerializeFabrik
    {
        public List<Kunde> ErstelleObjektVon(SerializeKunden sKunden)
        {
            List<Kunde> kunden = new List<Kunde>();
            foreach (var sKunde in sKunden.Kunden)
            {
                var bestellungen = new List<Bestellung>();
                foreach (var sBestellung in sKunde.Bestellungen)
                {
                    var rechnung = new Rechnung
                    {
                        RabattProzent = sBestellung.Rechnung.RabattProzent,
                        RechnungsNr = sBestellung.Rechnung.RechnungsNr,
                        RechnungsDatum = sBestellung.Rechnung.RechnungsDatum,
                    };

                    var bestellPositionen = new List<BestellPosition>();
                    foreach (var sBestellPosition in sBestellung.BestellPositionen)
                    {
                        bestellPositionen.Add(new BestellPosition(sBestellPosition.PositionsNr,
                            sBestellPosition.EinzelPreis, sBestellPosition.Menge)
                        {
                            Artikel = new Artikel
                            {
                                ArtikelNr = sBestellPosition.Artikel.ArtikelNr,
                                Bezeichnung = sBestellPosition.Artikel.Bezeichnung,
                                Produkthinweis = sBestellPosition.Artikel.Produkthinweis,
                            }
                        });
                    }

                    bestellungen.Add(new Bestellung
                    {
                        Rechnung = rechnung,
                        BestellNr = sBestellung.BestellNr,
                        BestellDatum = sBestellung.BestellDatum,
                        BestellPositionen = bestellPositionen
                    });
                }

                kunden.Add(new Kunde
                {
                    KundenNr = sKunde.KundenNr,
                    Name = sKunde.Name,
                    Ort = sKunde.Ort,
                    PLZ = sKunde.PLZ,
                    Strasse = sKunde.Strasse,
                    Bestellungen = bestellungen
                });

            }

            return kunden;
        }
    }
}