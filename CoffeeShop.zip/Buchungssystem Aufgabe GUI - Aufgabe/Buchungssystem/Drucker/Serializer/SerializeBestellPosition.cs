﻿namespace Buchungssystem
{
    public class SerializeBestellPosition
    {
        public int PositionsNr;
        public SerializeArtikel Artikel;
        public double EinzelPreis;
        public int Menge;
    }
}