﻿using System.Collections.Generic;

namespace Buchungssystem
{
    public class SerializeKunde
    {
        public string KundenNr;
        public string Name;
        public string Strasse;
        public string PLZ;
        public string Ort;
        public List<SerializeBestellung> Bestellungen;
    }
}