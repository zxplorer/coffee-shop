﻿using System.Collections.Generic;

namespace Buchungssystem
{
    class SerializeFabrik
    {
        public SerializeKunde ErstelleObjektVon(Kunde kunde)
        {
            var sBestellungen = new List<SerializeBestellung>();
            foreach (var bestellung in kunde.Bestellungen)
            {
                var sRechnung = SerializeRechnung(bestellung);
                var sBestellPosition = new List<SerializeBestellPosition>();
                foreach (var bestellPosition in bestellung.BestellPositionen)
                    SerializeBestellPosition(sBestellPosition, bestellPosition, SerializeArtikel(bestellPosition));
                SerializeBestellung(sBestellungen, bestellung, sRechnung, sBestellPosition);
            }
            return SerializeKunde(kunde, sBestellungen);
        }
        private static SerializeKunde SerializeKunde(Kunde kunde, List<SerializeBestellung> sBestellungen)
        {
            return new SerializeKunde
            {
                KundenNr = kunde.KundenNr,
                Name = kunde.Name,
                Ort = kunde.Ort,
                PLZ = kunde.PLZ,
                Strasse = kunde.Strasse,
                Bestellungen = sBestellungen,
            };
        }
        private static void SerializeBestellung(List<SerializeBestellung> sBestellungen, Bestellung bestellung, SerializeRechnung sRechnung, List<SerializeBestellPosition> sBestellPosition)
        {
            sBestellungen.Add(new SerializeBestellung
            {
                Rechnung = sRechnung,
                BestellDatum = bestellung.BestellDatum,
                BestellNr = bestellung.BestellNr,
                BestellPositionen = sBestellPosition
            });
        }
        private static void SerializeBestellPosition(List<SerializeBestellPosition> sBestellPosition, BestellPosition bestellPosition, SerializeArtikel sArtikel)
        {
            sBestellPosition.Add(new SerializeBestellPosition
            {
                PositionsNr = bestellPosition.PositionsNr,
                EinzelPreis = bestellPosition.EinzelPreis,
                Menge = bestellPosition.Menge,
                Artikel = sArtikel,
            });
        }
        private static SerializeArtikel SerializeArtikel(BestellPosition bestellPosition)
        {
            return new SerializeArtikel()
            {
                ArtikelNr = bestellPosition.Artikel.ArtikelNr,
                Bezeichnung = bestellPosition.Artikel.Bezeichnung,
                Produkthinweis = bestellPosition.Artikel.Produkthinweis,
            };
        }
        private static SerializeRechnung SerializeRechnung(Bestellung bestellung)
        {
            return new SerializeRechnung()
            {
                SummeNetto = bestellung.Rechnung.SummeNetto,
                RabattProzent = bestellung.Rechnung.RabattProzent,
                RechnungsNr = bestellung.Rechnung.RechnungsNr,
                RechnungsDatum = bestellung.Rechnung.RechnungsDatum,
                RabattPreis = bestellung.Rechnung.RabattPreis,
                NettoMitRabatt = bestellung.Rechnung.NettoMitRabatt,
                UstProzent = bestellung.Rechnung.UstProzent,
                UstAufschlag = bestellung.Rechnung.UstAufschlag,
                SummeBrutto = bestellung.Rechnung.SummeBrutto,
            };
        }
    }
}
