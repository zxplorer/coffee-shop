﻿using System;

namespace Buchungssystem
{
    public class SerializeRechnung
    {
        public double SummeNetto;
        public double RabattProzent;
        public string RechnungsNr;
        public DateTime RechnungsDatum;
        public double RabattPreis;
        public double NettoMitRabatt;
        public double UstProzent;
        public double UstAufschlag;
        public double SummeBrutto;
    }
}
