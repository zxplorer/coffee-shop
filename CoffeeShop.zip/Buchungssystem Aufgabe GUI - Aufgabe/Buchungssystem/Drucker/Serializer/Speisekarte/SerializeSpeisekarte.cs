﻿using System.Collections.Generic;
namespace Buchungssystem
{
    public class SerializeSpeisekarte
    {
        public List<SerializeSpeisekarteArtikel> Artikelliste;
        
    }
}