﻿namespace Buchungssystem
{
    public class SerializeSpeisekarteArtikel
    {
        public string ArtikelNr;
        public string Bezeichnung;
        public string Produkthinweis;
        public decimal? Einzelpreis;
    }
    
}