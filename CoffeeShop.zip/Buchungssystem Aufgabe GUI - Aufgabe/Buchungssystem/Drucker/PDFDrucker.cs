﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using iTextSharp.text;
using iTextSharp.text.pdf;
//Rechtklick auf das Projekt im Projektmappen-Explorer "Nuget Pakete verwalten..."
//iTextSharp installieren.

namespace Buchungssystem
{
    class PDFDrucker: IDrucker
    {
        public Kunde Kunde { get; set; }
        public string Dateipfad { get; set; }
        public void Open(string pfad)
        {
            Process.Start(pfad + Dateipfad + ".pdf");
        }

        private Document document;
        private FileStream fileStream;
        private PdfWriter writer;
        private readonly int MaxTableCols = 6;
        private readonly int TableColCount = 40;
        private readonly int[] TableColDimensions = { 5, 5, 11, 7, 5, 7 };
        private readonly List<string> TableHeaders = new List<string> { "Position", "ArtikelNr", "Bezeichnung", "Einzelpreis (EUR)", "Menge", "Preis (EUR)" };
        public void Rechnungsausgabe()
        {
            DokumentStart(Kunde);
            foreach (var bestellung in Kunde.Bestellungen)
            {
                var seite = 1;
                var zeile = 1;
                SeitenKopf(seite);
                RechnungsKopf(Kunde, bestellung);
                PositionsKopf();
                foreach (var bestellPosition in bestellung.BestellPositionen.OrderBy(x => x.PositionsNr))
                {
                    if (zeile % 20 == 0)
                    {
                        seite++;
                        SeitenKopf(seite);
                        PositionsKopf();
                    }
                    PositionsZeile(bestellPosition);
                    zeile++;
                }
                RechnungsFuss(bestellung.Rechnung);
            }
            DokumentEnde();
        }
        private void DokumentStart(Kunde kunde)
        {
            fileStream = new FileStream(Dateipfad + ".pdf", FileMode.OpenOrCreate);
            document = new Document(PageSize.A4, 20, 20, 20, 20);
            writer = PdfWriter.GetInstance(document, fileStream);
            document.Open();
            document.NewPage();
        }
        private void DokumentEnde()
        {
            document.Close();
            fileStream.Close();
        }
        private void SeitenKopf(int seite)
        {
            AddParagraph(new StringBuilder($"Seite {seite}"), Element.ALIGN_RIGHT);
        }
        private void WriteTableRow(List<string> strings, bool isHeader = false)
        {
            var table = new PdfPTable(TableColCount);

            for (int i = 0; i < MaxTableCols; i++)
            {
                var cell = new PdfPCell()
                {
                    Phrase = new Phrase(strings.ElementAt(i)),
                    Colspan = TableColDimensions[i]
                };
                cell.DisableBorderSide(Rectangle.LEFT_BORDER);
                cell.DisableBorderSide(Rectangle.TOP_BORDER);
                cell.DisableBorderSide(Rectangle.RIGHT_BORDER);
                if (!isHeader)
                    cell.DisableBorderSide(Rectangle.BOTTOM_BORDER);

                table.AddCell(cell);
            }
            document.Add(table);
        }
        private void RechnungsKopf(Kunde kunde, Bestellung bestellung)
        {
            var builder1 = new StringBuilder();
            builder1.Append($"{kunde.Name} \n");
            builder1.Append($"{kunde.Strasse} \n");
            builder1.Append($"{kunde.PLZ} {kunde.Ort} \n\n");
            AddParagraph(builder1, Element.ALIGN_LEFT);

            var builder2 = new StringBuilder();
            builder2.Append($"Rechnungsdatum: {bestellung.Rechnung.RechnungsDatum.Date.ToString("d")}\n");
            builder2.Append($"Rechnungsnummer: {bestellung.Rechnung.RechnungsNr}\n");
            builder2.Append($"Kundennummer: {kunde.KundenNr}\n\n");
            AddParagraph(builder2, Element.ALIGN_RIGHT);

            var builder3 = new StringBuilder();
            builder3.Append($"Ihre Bestellung {bestellung.BestellNr} vom {bestellung.BestellDatum.Date.ToString("d")}\n\n");
            AddParagraph(builder3, Element.ALIGN_LEFT);
        }
        private void AddParagraph(StringBuilder sb, int element)
        {
            var paragraph = new Paragraph(sb.ToString())
            {
                SpacingBefore = 0,
                SpacingAfter = 0,
                ExtraParagraphSpace = 0,
                Alignment = element,
                Font = FontFactory.GetFont(FontFactory.HELVETICA, 12f, BaseColor.BLACK)
            };
            document.Add(paragraph);
        }
        private void RechnungsFuss(Rechnung rechnung)
        {
            var rabattProzent = Convert.ToInt32(rechnung.RabattProzent * 100);
            var stringBuilder = new StringBuilder();
            stringBuilder.Append($"\nSumme netto   {rechnung.SummeNetto}\n");
            stringBuilder.Append($"RabattProzent ({rabattProzent}%)     {rechnung.RabattPreis}\n");
            stringBuilder.Append($"Summe netto abzgl. RabattProzent   {rechnung.NettoMitRabatt}\n");
            stringBuilder.Append($"USt({rechnung.UstProzent * 100}%)    {rechnung.UstAufschlag}\n");
            stringBuilder.Append($"Summe brutto    {rechnung.SummeBrutto}\n");
            AddParagraph(stringBuilder, Element.ALIGN_RIGHT);
        }
        private void PositionsKopf()
        {
            WriteTableRow(TableHeaders, true);
        }
        private void PositionsZeile(BestellPosition pos)
        {
            WriteTableRow(new List<string>
            {
                $"{pos.PositionsNr}",
                $"{pos.Artikel.ArtikelNr}",
                pos.Artikel.Bezeichnung,
                string.Format("{0:0.00}", pos.EinzelPreis),
                $"{pos.Menge}",
                string.Format("{0:0.00}", pos.EinzelPreis * pos.Menge)
            });
        }
    }
}