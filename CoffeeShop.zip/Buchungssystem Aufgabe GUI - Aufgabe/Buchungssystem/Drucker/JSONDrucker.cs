﻿using System.Diagnostics;
using System.IO;
using System.Web.Script.Serialization;

namespace Buchungssystem
{
    internal class JSONDrucker : IDrucker
    {
        public Kunde Kunde { get; set; }
        public string Dateipfad { get; set; }
        public void Open(string pfad)
        {
            Process.Start(pfad + Dateipfad + ".json");
        }

        public void Rechnungsausgabe()
        {
            var fabrik = new SerializeFabrik();
            var json = new JavaScriptSerializer().Serialize(fabrik.ErstelleObjektVon(Kunde));

            StreamWriter outputFile = new StreamWriter(Dateipfad + ".json");
            outputFile.WriteLine(json);
            outputFile.Close();
        }
    }
}