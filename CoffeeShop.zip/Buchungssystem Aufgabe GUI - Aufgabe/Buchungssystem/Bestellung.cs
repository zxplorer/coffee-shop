﻿using System;
using System.Collections.Generic;

namespace Buchungssystem
{
    public class Bestellung
    {
        private List<BestellPosition> _bestellPositionen = new List<BestellPosition>();
        public string BestellNr { get; set; }
        public DateTime BestellDatum { get; set; }
        public Rechnung Rechnung { get; set; }
        public List<BestellPosition> BestellPositionen
        {
            get { return _bestellPositionen; }
            set
            {
                _bestellPositionen = value;
                  KalkuliereSummeNetto();            
            }
        }

          private void KalkuliereSummeNetto()
           {          
               Rechnung.SummeNetto = 0;
               foreach (var position in BestellPositionen)
               Rechnung.SummeNetto += position.EinzelPreis * position.Menge;      
           }
                 
    }

}