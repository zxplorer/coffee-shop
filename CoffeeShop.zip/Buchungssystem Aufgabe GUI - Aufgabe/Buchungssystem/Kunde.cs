﻿using System.Collections.Generic;

namespace Buchungssystem
{
     public class Kunde
    {
        public string KundenNr { get; set; }
        public string Name { get; set; }
        public string Strasse { get; set; }
        public string PLZ { get; set; }
        public string Ort { get; set; }

        public List<Bestellung> Bestellungen { get; set; }
    }
}
